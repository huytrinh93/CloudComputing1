<html>
<head>
</head>
<body>

<img src="<?php $showimage="img2.jpg";echo $showimage;?>" height="100%"/>
<br/><br/>
<input type="button" value="Refresh Page" onClick="window.location.reload()">
</body>
</html>
